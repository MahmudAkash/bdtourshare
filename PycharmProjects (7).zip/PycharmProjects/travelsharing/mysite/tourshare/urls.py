from django.urls import path
from. import views

urlpatterns = [
   path("",views.index,name="toursharehome"),
   path("About/",views.About,name="About"),
   path("Contact/",views.Contact,name="Contact"),
   path("Checkout/", views.Checkout, name="checkout"),

]