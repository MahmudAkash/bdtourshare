from django.contrib import admin

# Register your models here.
from .models import Group,checkout,contact
admin.site.register(Group)
admin.site.register(checkout)
admin.site.register(contact)