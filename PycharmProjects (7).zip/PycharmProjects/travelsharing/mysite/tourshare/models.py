from django.db import models

# Create your models here.
class Group(models.Model):
    Group_Id=models.AutoField
    Group_Name=models.CharField(max_length=50)
    Desc=models.CharField(max_length=300)
    Pub_Date=models.DateField()

    def __str__(self):
        return self.Group_Name
class checkout(models.Model):
    msg_id = models.AutoField(primary_key=True)
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=70,default="")
    people=models.CharField(max_length=70,default="")
    phone=models.CharField(max_length=70,default="")
    def __str__(self):
        return self.name
class contact(models.Model):
    msg_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    desc = models.CharField(max_length=500, default="")


    def __str__(self):
        return self.name