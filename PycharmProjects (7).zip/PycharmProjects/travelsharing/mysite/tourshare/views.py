from django.shortcuts import render
from.models import checkout,contact

# Create your views here.
from django.http import HttpResponse
def index (request):
    return render(request,'tourshare/index.html')
def About(request):
    return render(request,'tourshare/about.html')
def Contact(request):
    if request.method == "POST":
        print(request)
        name=request.POST.get('name','')
        email=request.POST.get('email', '')
        phone=request.POST.get('phone', '')
        desc=request.POST.get('desc', '')
        print(name,email,phone,desc)
        Contact=contact(name=name,email=email,phone=phone,desc=desc)
        Contact.save()

    return render(request,'tourshare/Contact.html')
def Checkout(request):
    if request.method=="POST":

        name=request.POST.get('name','')
        email = request.POST.get('email', '')
        people = request.POST.get('people', '')
        phone = request.POST.get('phone', '')
        print(name,email,people,phone)
        Checkout=checkout(name=name,email=email,people=people,phone=phone)
        Checkout.save()
    return render(request, 'tourshare/Checkout.html')