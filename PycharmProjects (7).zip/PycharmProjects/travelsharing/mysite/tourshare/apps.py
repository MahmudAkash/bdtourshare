from django.apps import AppConfig


class TourshareConfig(AppConfig):
    name = 'tourshare'
